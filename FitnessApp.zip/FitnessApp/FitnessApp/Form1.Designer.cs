﻿namespace FitnessApp
{
    partial class heightTB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pageTitle = new System.Windows.Forms.Label();
            this.intoLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.feetTB = new System.Windows.Forms.TextBox();
            this.feetLabel = new System.Windows.Forms.Label();
            this.inchesTB = new System.Windows.Forms.TextBox();
            this.inchesLabel = new System.Windows.Forms.Label();
            this.genderLabel = new System.Windows.Forms.Label();
            this.manRB = new System.Windows.Forms.RadioButton();
            this.womanRB = new System.Windows.Forms.RadioButton();
            this.weightLB = new System.Windows.Forms.Label();
            this.weightTB = new System.Windows.Forms.TextBox();
            this.poundsLB = new System.Windows.Forms.Label();
            this.wgtLossGoalLB = new System.Windows.Forms.Label();
            this.idealWghtTB = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.goalDateLB = new System.Windows.Forms.Label();
            this.howActiveLB = new System.Windows.Forms.Label();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.eatingLB = new System.Windows.Forms.Label();
            this.eatingHabitCB = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Submit = new System.Windows.Forms.Button();
            this.activeRLB = new System.Windows.Forms.Label();
            this.activeLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pageTitle
            // 
            this.pageTitle.AutoSize = true;
            this.pageTitle.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pageTitle.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.pageTitle.Location = new System.Drawing.Point(458, 32);
            this.pageTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pageTitle.Name = "pageTitle";
            this.pageTitle.Size = new System.Drawing.Size(92, 21);
            this.pageTitle.TabIndex = 0;
            this.pageTitle.Text = "FitJourney";
            this.pageTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // intoLabel
            // 
            this.intoLabel.AutoSize = true;
            this.intoLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.intoLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.intoLabel.Location = new System.Drawing.Point(66, 129);
            this.intoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.intoLabel.Name = "intoLabel";
            this.intoLabel.Size = new System.Drawing.Size(256, 21);
            this.intoLabel.TabIndex = 1;
            this.intoLabel.Text = "Lets start with some questions!";
            this.intoLabel.Click += new System.EventHandler(this.bmiLabel_Click);
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heightLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.heightLabel.Location = new System.Drawing.Point(67, 224);
            this.heightLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(214, 21);
            this.heightLabel.TabIndex = 2;
            this.heightLabel.Text = "How tall are you? (In feet)";
            // 
            // feetTB
            // 
            this.feetTB.Location = new System.Drawing.Point(289, 224);
            this.feetTB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.feetTB.Name = "feetTB";
            this.feetTB.Size = new System.Drawing.Size(47, 21);
            this.feetTB.TabIndex = 3;
            // 
            // feetLabel
            // 
            this.feetLabel.AutoSize = true;
            this.feetLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feetLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.feetLabel.Location = new System.Drawing.Point(344, 224);
            this.feetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.feetLabel.Name = "feetLabel";
            this.feetLabel.Size = new System.Drawing.Size(40, 21);
            this.feetLabel.TabIndex = 4;
            this.feetLabel.Text = "feet";
            // 
            // inchesTB
            // 
            this.inchesTB.Location = new System.Drawing.Point(392, 224);
            this.inchesTB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.inchesTB.Name = "inchesTB";
            this.inchesTB.Size = new System.Drawing.Size(47, 21);
            this.inchesTB.TabIndex = 5;
            // 
            // inchesLabel
            // 
            this.inchesLabel.AutoSize = true;
            this.inchesLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inchesLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.inchesLabel.Location = new System.Drawing.Point(447, 224);
            this.inchesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.inchesLabel.Name = "inchesLabel";
            this.inchesLabel.Size = new System.Drawing.Size(60, 21);
            this.inchesLabel.TabIndex = 6;
            this.inchesLabel.Text = "inches";
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.genderLabel.Location = new System.Drawing.Point(67, 183);
            this.genderLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(178, 21);
            this.genderLabel.TabIndex = 7;
            this.genderLabel.Text = "What is your gender?";
            // 
            // manRB
            // 
            this.manRB.AutoSize = true;
            this.manRB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manRB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.manRB.Location = new System.Drawing.Point(260, 183);
            this.manRB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.manRB.Name = "manRB";
            this.manRB.Size = new System.Drawing.Size(62, 25);
            this.manRB.TabIndex = 8;
            this.manRB.TabStop = true;
            this.manRB.Text = "Man";
            this.manRB.UseVisualStyleBackColor = true;
            this.manRB.CheckedChanged += new System.EventHandler(this.manRB_CheckedChanged);
            // 
            // womanRB
            // 
            this.womanRB.AutoSize = true;
            this.womanRB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.womanRB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.womanRB.Location = new System.Drawing.Point(336, 183);
            this.womanRB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.womanRB.Name = "womanRB";
            this.womanRB.Size = new System.Drawing.Size(88, 25);
            this.womanRB.TabIndex = 11;
            this.womanRB.TabStop = true;
            this.womanRB.Text = "Woman";
            this.womanRB.UseVisualStyleBackColor = true;
            this.womanRB.CheckedChanged += new System.EventHandler(this.womanRB_CheckedChanged);
            // 
            // weightLB
            // 
            this.weightLB.AutoSize = true;
            this.weightLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.weightLB.Location = new System.Drawing.Point(67, 264);
            this.weightLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.weightLB.Name = "weightLB";
            this.weightLB.Size = new System.Drawing.Size(307, 21);
            this.weightLB.TabIndex = 13;
            this.weightLB.Text = "How much do you weigh? (In pounds)";
            // 
            // weightTB
            // 
            this.weightTB.Location = new System.Drawing.Point(382, 266);
            this.weightTB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.weightTB.Name = "weightTB";
            this.weightTB.Size = new System.Drawing.Size(68, 21);
            this.weightTB.TabIndex = 14;
            // 
            // poundsLB
            // 
            this.poundsLB.AutoSize = true;
            this.poundsLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.poundsLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.poundsLB.Location = new System.Drawing.Point(458, 266);
            this.poundsLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.poundsLB.Name = "poundsLB";
            this.poundsLB.Size = new System.Drawing.Size(68, 21);
            this.poundsLB.TabIndex = 15;
            this.poundsLB.Text = "pounds";
            // 
            // wgtLossGoalLB
            // 
            this.wgtLossGoalLB.AutoSize = true;
            this.wgtLossGoalLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wgtLossGoalLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.wgtLossGoalLB.Location = new System.Drawing.Point(67, 306);
            this.wgtLossGoalLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.wgtLossGoalLB.Name = "wgtLossGoalLB";
            this.wgtLossGoalLB.Size = new System.Drawing.Size(353, 21);
            this.wgtLossGoalLB.TabIndex = 16;
            this.wgtLossGoalLB.Text = "What is your ideal weight goal? (In pounds)";
            // 
            // idealWghtTB
            // 
            this.idealWghtTB.Location = new System.Drawing.Point(433, 306);
            this.idealWghtTB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.idealWghtTB.Name = "idealWghtTB";
            this.idealWghtTB.Size = new System.Drawing.Size(75, 21);
            this.idealWghtTB.TabIndex = 17;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Britannic Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(512, 343);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 21);
            this.dateTimePicker1.TabIndex = 18;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // goalDateLB
            // 
            this.goalDateLB.AutoSize = true;
            this.goalDateLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goalDateLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.goalDateLB.Location = new System.Drawing.Point(67, 343);
            this.goalDateLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.goalDateLB.Name = "goalDateLB";
            this.goalDateLB.Size = new System.Drawing.Size(437, 21);
            this.goalDateLB.TabIndex = 19;
            this.goalDateLB.Text = "By what date would ideally want to achieve your goal?";
            // 
            // howActiveLB
            // 
            this.howActiveLB.AutoSize = true;
            this.howActiveLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.howActiveLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.howActiveLB.Location = new System.Drawing.Point(66, 380);
            this.howActiveLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.howActiveLB.Name = "howActiveLB";
            this.howActiveLB.Size = new System.Drawing.Size(478, 21);
            this.howActiveLB.TabIndex = 20;
            this.howActiveLB.Text = "On a scale from 1 to 10, how active would you say you are?";
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.LargeChange = 1;
            this.hScrollBar1.Location = new System.Drawing.Point(637, 384);
            this.hScrollBar1.Maximum = 10;
            this.hScrollBar1.Minimum = 1;
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(259, 17);
            this.hScrollBar1.TabIndex = 21;
            this.hScrollBar1.Value = 1;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(735, 58);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 246);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // eatingLB
            // 
            this.eatingLB.AutoSize = true;
            this.eatingLB.BackColor = System.Drawing.SystemColors.Window;
            this.eatingLB.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eatingLB.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.eatingLB.Location = new System.Drawing.Point(67, 418);
            this.eatingLB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.eatingLB.Name = "eatingLB";
            this.eatingLB.Size = new System.Drawing.Size(359, 21);
            this.eatingLB.TabIndex = 24;
            this.eatingLB.Text = "How would you describe your eating habits?";
            // 
            // eatingHabitCB
            // 
            this.eatingHabitCB.FormattingEnabled = true;
            this.eatingHabitCB.Items.AddRange(new object[] {
            "Mostly carbs and meat with small portion of vegetables",
            "Mostly meat with even portion of carbs and vegetables",
            "Mostly vegetables with small portion of meat and carbs",
            "Mostly vegetables with small amount of carbs and no meat",
            "All vegetables",
            "Vegan"});
            this.eatingHabitCB.Location = new System.Drawing.Point(434, 416);
            this.eatingHabitCB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.eatingHabitCB.Name = "eatingHabitCB";
            this.eatingHabitCB.Size = new System.Drawing.Size(376, 23);
            this.eatingHabitCB.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.label1.Location = new System.Drawing.Point(516, 306);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 21);
            this.label1.TabIndex = 26;
            this.label1.Text = "pounds";
            // 
            // Submit
            // 
            this.Submit.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit.Location = new System.Drawing.Point(433, 472);
            this.Submit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(205, 38);
            this.Submit.TabIndex = 27;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // activeRLB
            // 
            this.activeRLB.AutoSize = true;
            this.activeRLB.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeRLB.Location = new System.Drawing.Point(552, 384);
            this.activeRLB.Name = "activeRLB";
            this.activeRLB.Size = new System.Drawing.Size(0, 18);
            this.activeRLB.TabIndex = 28;
            // 
            // activeLabel
            // 
            this.activeLabel.AutoSize = true;
            this.activeLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeLabel.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.activeLabel.Location = new System.Drawing.Point(558, 382);
            this.activeLabel.Name = "activeLabel";
            this.activeLabel.Size = new System.Drawing.Size(0, 21);
            this.activeLabel.TabIndex = 29;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.Location = new System.Drawing.Point(70, 536);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(765, 151);
            this.textBox1.TabIndex = 30;
            this.textBox1.Text = "\r\n\r\n\r\n";
            // 
            // heightTB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1019, 719);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.activeLabel);
            this.Controls.Add(this.activeRLB);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.eatingHabitCB);
            this.Controls.Add(this.eatingLB);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.hScrollBar1);
            this.Controls.Add(this.howActiveLB);
            this.Controls.Add(this.goalDateLB);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.idealWghtTB);
            this.Controls.Add(this.wgtLossGoalLB);
            this.Controls.Add(this.poundsLB);
            this.Controls.Add(this.weightTB);
            this.Controls.Add(this.weightLB);
            this.Controls.Add(this.womanRB);
            this.Controls.Add(this.manRB);
            this.Controls.Add(this.genderLabel);
            this.Controls.Add(this.inchesLabel);
            this.Controls.Add(this.inchesTB);
            this.Controls.Add(this.feetLabel);
            this.Controls.Add(this.feetTB);
            this.Controls.Add(this.heightLabel);
            this.Controls.Add(this.intoLabel);
            this.Controls.Add(this.pageTitle);
            this.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "heightTB";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.heightTB_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pageTitle;
        private System.Windows.Forms.Label intoLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.TextBox feetTB;
        private System.Windows.Forms.Label feetLabel;
        private System.Windows.Forms.TextBox inchesTB;
        private System.Windows.Forms.Label inchesLabel;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.RadioButton manRB;
        private System.Windows.Forms.RadioButton womanRB;
        private System.Windows.Forms.Label weightLB;
        private System.Windows.Forms.TextBox weightTB;
        private System.Windows.Forms.Label poundsLB;
        private System.Windows.Forms.Label wgtLossGoalLB;
        private System.Windows.Forms.TextBox idealWghtTB;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label goalDateLB;
        private System.Windows.Forms.Label howActiveLB;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label eatingLB;
        private System.Windows.Forms.ComboBox eatingHabitCB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Label activeRLB;
        private System.Windows.Forms.Label activeLabel;
        private System.Windows.Forms.TextBox textBox1;
    }
}


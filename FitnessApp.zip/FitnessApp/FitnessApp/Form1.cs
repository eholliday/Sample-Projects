﻿// ==========================================================     
// Title:  Form1.cs     
// Author: Eleanor Holliday    
// Contributors:  None  
// Purpose:   User Interface for the program for the user to put in 
// their sex, height, weight, diet, and exercise routine and 
// provide the user with recommendation
// on how to get to their desired weight.  
// ==========================================================

using System;
using System.Drawing;
using System.Windows.Forms;

namespace FitnessApp
{
    public partial class heightTB : Form
    {
        public heightTB()
        {
            InitializeComponent();
           
        }

        private void bmiLabel_Click(object sender, EventArgs e)
        {

        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            // Scroll bar control the numbers ranging 1-10 that represent
            // how active a user is. 
            activeLabel.Text = hScrollBar1.Value.ToString();
        }
        private void isWoman()
        {
            if(womanRB.Checked)
            {
                

                //Calls the Woman class
                Woman woman = new Woman(Convert.ToInt32(feetTB.Text), Convert.ToInt32(inchesTB.Text), Convert.ToInt32(weightTB.Text), 
                    Convert.ToInt32(idealWghtTB.Text), difference() ,Convert.ToInt32(activeLabel.Text), eatingHabitCB.Text);
                //Prints the results from the Womans calculations
                textBox1.Text = woman.printResults();           
            }
        }
        private double difference()
        {
            // Retrives the selected date by the user from the calendar
            DateTime dateSelection = dateTimePicker1.Value;

            //Retrives todays date
            DateTime today = DateTime.Now;

            // Takes the difference between today and the day selected by the user
            TimeSpan difference = dateSelection - today;
            // Takes the difference found and turns it into a number
            var numberOfDays = Math.Round(difference.TotalDays);

            return numberOfDays;
        }
        private void isMan()
        {
            // if the man radio button is selected, the man class will be run and the calculations and recommendations will be tailored to a man
            if(manRB.Checked)
            {
                Man man = new Man(Convert.ToInt32(feetTB.Text), Convert.ToInt32(inchesTB.Text), Convert.ToInt32(weightTB.Text),
                    Convert.ToInt32(idealWghtTB.Text), difference(), Convert.ToInt32(activeLabel.Text), eatingHabitCB.Text);
                //Prints the results from the Womans calculations
                textBox1.Text = man.printResults();
            }
        }
        
        private void heightTB_Load(object sender, EventArgs e)
        {
            //ensures that the background color for the labels are
            //transparent to blend in with the background.
            womanRB.BackColor = System.Drawing.Color.Transparent;
            manRB.BackColor = System.Drawing.Color.Transparent;
            pageTitle.BackColor = System.Drawing.Color.Transparent;
            intoLabel.BackColor = System.Drawing.Color.Transparent;
            heightLabel.BackColor = System.Drawing.Color.Transparent;
            genderLabel.BackColor = System.Drawing.Color.Transparent;
            feetLabel.BackColor = System.Drawing.Color.Transparent;
            inchesLabel.BackColor = System.Drawing.Color.Transparent;
            weightLB.BackColor = System.Drawing.Color.Transparent;
            poundsLB.BackColor = System.Drawing.Color.Transparent;
            wgtLossGoalLB.BackColor = System.Drawing.Color.Transparent;
            goalDateLB.BackColor = System.Drawing.Color.Transparent;
            howActiveLB.BackColor = System.Drawing.Color.Transparent;
            eatingLB.BackColor = System.Drawing.Color.Transparent;
       
        }
  
        private void Submit_Click(object sender, EventArgs e)
        {
            // When submit is pressed the man and woman methods are executed
            isWoman();
            isMan();          
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void womanRB_CheckedChanged(object sender, EventArgs e)
        {
            //When the user selects the man radio button, the symbol of a woman is placed in the picture box
            pictureBox1.Image = Image.FromFile("C:\\FitnessApp\\Project_pictures\\woman.png");
        }

        private void manRB_CheckedChanged(object sender, EventArgs e)
        {
            //When the user selects the man radio button, the symbol of a man is placed in the picture box
            pictureBox1.Image = Image.FromFile("C:\\FitnessApp\\Project_pictures\\man.png");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
    }
}

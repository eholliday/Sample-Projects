﻿// ==========================================================     
// Title:  Woman.cs     
// Author: Eleanor Holliday    
// Contributors:  None  
// Purpose:   This program takes the weight, height, diet, 
// and exercise routine and provides the user with recommendation
// on how to get to their desired weight.  
// ==========================================================

using System;

namespace FitnessApp
{
    class Woman
    {
        public int feet;
        public int inches;
        public int weight;
        public int idealWeight;
        public double numberOfDays;
        public int howActive;
        public string eating;
         
        public Woman(int _feet, int _inches, int _weight, int _idealWeight, double _numberOfDays, int _howActive, string _eating) // Constructor for the Woman class
        {
            feet = _feet;
            inches = _inches;
            weight = _weight;
            idealWeight = _idealWeight;
            numberOfDays = _numberOfDays;
            howActive = _howActive;
            eating = _eating;
          
        }
  
        public string printResults() // Displays the advice for the user according to the information that was entered
        {
           string resultText  = "Your BMI is: " + calculateBMI() + ". " + bmiResult() + " ";
           resultText += "You have " + numberOfDays + " days to lose " + difference() + " pounds. ";
           resultText += "My suggestion for you to reach your goal of " + idealWeight + " pounds is to " + eatingHabits() + activePerson();     
           return resultText; 
        }
        private double calculateBMI() // Calculates the BMI of the female user
        {
         
            double usWeight = weight * 703;
            int feetConversion = (feet * 12) + inches;
            double squared = feetConversion * feetConversion;
            double bmiTotal = Math.Round((usWeight / squared), 2);

            return bmiTotal; 
        }
        private string bmiResult() // Displays the information about the range the users BMI falls into
        {
            string bmiText = "";

            if (calculateBMI() < 18.5) // if the the calculated BMI is less than the standard healthy range 18.5, user is underweight
            {
                bmiText = "Your weight is within an underweight range for a woman.";
            }

            if (calculateBMI() < 24.9 && calculateBMI() > 18.5) // If the calculated BMI is within 18.5 and 24.9 (range for healthy), user is a healthy weight
            {
                bmiText = "Your weight is within a normal range for a woman.";
            }

            if (calculateBMI() < 29.9 && calculateBMI() > 25.0) // If the calculated BMI is between 25.0 and 299 (range for overweight), user is overweight
            {
                bmiText = "Your weight is within the range of overweight for a woman.";
            }
            if (calculateBMI() > 30.0) // If the calculated BMI is over 30.0 the user is obese
            {
                bmiText = "Your weight is within the range of obese for a woman.";
            }
            return bmiText;
        }
        private int difference() // Get the difference between the users current weight, and the desired weight to obtain
        {
            int weightDifference = weight - idealWeight;
            return weightDifference; 
        }
        private string activePerson() // Determines how much physical actvity the user needs to do based on the information provided.
        {
            string activity = "";

            if (howActive < 4) // On a scale from 1-10 if the user was less active than four 
            {
                activity = "You need to also increase your physical activity to at least 4-5"; 
                activity += "times a week for 1 hour with cardio intensive exercise. ";
            }
            if(howActive == 5 || howActive == 6) // On a scale from 1-10 if hte user was active between 5 and 6
            {
                activity = "Your physical activity could be better. You should try to work out about 4-5"; 
                activity += "times a week for at least one hour, and ensure that the exercise is cardio intensive. ";
            }
            if(howActive == 7 || howActive == 8 || howActive == 9 || howActive == 10) // One a scale from 1-10 if the user was 7, 8, 9, or 10
            {
                activity = "Your physical actvity is very active! This is great for overall health. Keep in mind however";
                activity += "that over working your body has reprocussions, and you should ensure that you take 2 days off every week!";
            }

            return activity; // returns the recommendation of physical activity
        }
        private string eatingHabits() // Determines the best diet for the user depending by mathching the eating habits the user entered
        {
            string results = ""; //sets the strint to be returned as an empty string

            if(eating == "Mostly carbs and meat with small portion of vegetables") // If their eating habits match each of the strings below
            {
                results = "focus on making vegetables the largest portion of your meal, limiting the amount of carbs to a couple of times per week";
                results += " and having smaller portions of meat. Consider eating fish like salmon.";
                results += " Also focus on including fruits into your diet. Foods should be cooked with no oil! "; 
            }
            if(eating == "Mostly meat with even portion of carbs and vegetables")
            {
                results = "be wary that vegetables should be the largest portion of your meal, with carbs being eaten only couple of times per week.";
                results += " Meat should also be limited. Also focus on including fruits into your diet. Foods should be cooked with no oil! ";
            }
            if(eating == "Mostly vegetables with small portion of meat and carbs")
            {
                results = "make sure the less carb consumption you have, the better.";
                results += " Hopefully your diet also consitsts of fruits to obtain important nutrients.";
                results += " Meat should be consumed in smaller quantities as well and also limited. Also focus on including fruits into your diet. ";
            }
            if(eating == "Mostly vegetables with small amount of carbs and no meat")
            {
                results = "be cautious to have some sort of protein in your diet";
                results += " or take b-12 vitamins. Also make sure that the carb intake is still limited. ";
            }
            if(eating == "All vegetables")
            {
                results = "make sure you are getting protein from somewhere or try to make sure you take vitamin supplements specifically B-12. ";
            }
            if(eating == "Vegan")
            {
                results = "be cautious with your diet and make sure you are obtaining enough B-12 vitamins. Having a deficit in B-12 can lead to";
                results += " problems with your nerves, and digestive problems because of the lack of protein. ";
            }

            return results; // returns the string of advice that matches the users current dietary status
        }

  
    }
}
